package com.example.safetech.data.database

class DatabaseSource {
}